# Tema Heavy Metal — AGENTE-GPT / Mark LVI

Esta cópia mantém a base original e aplica somente uma identidade visual alternativa:

- Paleta monocromática preto, branco, prata e cinza.
- Caveira ☠ no cabeçalho e no HUD central, com brilho suave e animação visual ligada ao estado da agente.
- Núcleo reator continua disponível como alternativa pelo controle HUD.
- Painel remoto do celular com o mesmo tema preto e branco.
- Os fluxos de conexão, autenticação, QR Code e comandos remotos existentes foram preservados.

## Controle pelo celular

A base original fornece controle remoto pela rede Wi-Fi (mesma rede local, usando o painel/QR Code). Bluetooth não está implementado nesta base; adicioná-lo exigiria uma funcionalidade separada e não faz parte desta alteração exclusivamente visual.

## Importante

Esta é uma cópia temática separada. Guarde o ZIP original e configure as chaves/API conforme o README original antes de iniciar. O tema não remove a necessidade de configuração do provedor de IA escolhido.
